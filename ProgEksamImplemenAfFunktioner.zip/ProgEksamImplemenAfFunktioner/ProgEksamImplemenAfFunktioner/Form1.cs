﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MathNet.Numerics;
using MathNet.Numerics.RootFinding;


namespace ProgEksamImplemenAfFunktioner
{
    public partial class Form1 : Form
    {
        // Laserstråle
        //Func<double, double> f = x => -4 * x + 3;

        // Liste over objekter (funktioner og deres intervaller)
        private readonly List<(Func<double, double> funktion, double start, double end, string navn)> funktioner =
    new List<(Func<double, double> funktion, double start, double end, string navn)>
    {
        // TIlføj flere funktioner her
        //Første reflekterede
        (x => x >= 0.37 && x <= 1.24 ? 0.39 * x + 1.3 : double.NaN, 0.37, 1.24, "j"),
        //Anden reflekterede 
        (x => x >= 0.8 && x <= 2 ? -0.27 * x + 0.54 : double.NaN , 0.8, 2, "p"),
        //Tredje reflekterede 
        (x => x >= 3.4 && x <= 3.52 ? 3.06*x-8.87 : double.NaN, 3.4, 3.52, "k"),
        //Fjerde reflekterede
        (x => x >= 2.75 && x <= 3.44 ? -0.53*x+4.5 : double.NaN, 2.75, 3.44, "l"),
        //Femte reflekterede
        (x => x >= -0.85 && x <= -0.23 ? 0.36 * x + 2.41 : double.NaN, -0.83, -0.23, "d")
    };

        // Liste over de beregnede laserpositioner
        private List<PointF> laserPath = new List<PointF>();

        public Form1()
        {
            InitializeComponent();
            BeregnSkæringer();

            this.DoubleBuffered = true; // Forhindrer flimmer
            
        }
        private void BeregnSkæringer()
        {
            // Hældning a (f.eks. -3)
            double a = -10;

            // Startpunktet (xStart, yStart)
            double xStart = 0.75;
            double yStart = 0;

            // Beregn b-værdien ud fra startpunktet og hældningen
            double b = yStart - a * xStart;

            // Definer laserStart funktionen dynamisk med den beregnede b-værdi
            Func<double, double> laserStart = x => a * x + b;

            // Output for at tjekke den nye laserStart funktion
            Console.WriteLine($"Laserens funktion: f(x) = {a}x + {b}");

            StartLaserReflections(laserStart, xStart, yStart);
        }

       
        //Når formens størrelse ændres kaldes Invalidate(),
        //hvilket genopfrisker skærmen og genberegner de nødvendige skaleringsfaktorer.
        private void Form1_ClientSizeChanged(object sender, EventArgs e)
        {
            // Når størrelsen på klientområdet ændres, opdater tegningen
            this.Invalidate();  // Genopfrisk form’en og opdater visualiseringen
        }
        // Når formen skal tegnes, bruges denne metode til at visualisere laserens bane og reflektioner
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            // Opret grafikobjekt
            Graphics g = e.Graphics;

            // Beregn skaleringsfaktorer for x og y
            double xMin = double.MaxValue;
            double xMax = double.MinValue;
            double yMin = double.MaxValue;
            double yMax = double.MinValue;

            // Find minimum og maksimum for både x og y (for både funktioner og laser)
            // Iterér først igennem funktionerne
            foreach (var (funktion, start, end, navn) in funktioner)
            {
                for (double x = start; x <= end; x += 0.01)
                {
                    double y = funktion(x);
                    if (!double.IsNaN(y))
                    {
                        xMin = Math.Min(xMin, x);
                        xMax = Math.Max(xMax, x);
                        yMin = Math.Min(yMin, y);
                        yMax = Math.Max(yMax, y);
                    }
                }
            }

            // Tilføj laserens punkter til min/max beregningen
            foreach (var point in laserPath)
            {
                xMin = Math.Min(xMin, point.X);
                xMax = Math.Max(xMax, point.X);
                yMin = Math.Min(yMin, point.Y);
                yMax = Math.Max(yMax, point.Y);
            }

            // Beregn skaleringsfaktorer baseret på formens dimensioner
            double scaleX = this.ClientSize.Width / (float)(xMax - xMin);
            double scaleY = this.ClientSize.Height / (float)(yMax - yMin);

            // Debugging: Udskriv skaleringsfaktorer
            Console.WriteLine($"scaleX: {scaleX}, scaleY: {scaleY}");


            // Tegn funktionerne (spejlene)
            foreach (var (funktion, start, end, navn) in funktioner)
            {
                Pen pen = new Pen(Color.Blue, 2);  // Blå pen til funktionerne
                DrawFunction(g, funktion, start, end, pen, scaleX, scaleY, xMin, yMin);
            }

            // Tegn et rødt punkt ved laserens startpunkt
            PointF startPoint = new PointF((float)0.75, (float)0); // Laserens startpunkt (her hardcoded)
            PointF scaledStartPoint = ScalePoint(startPoint, scaleX, scaleY, xMin, yMin); // Skaler punktet
            Brush startBrush = new SolidBrush(Color.Red); // Rød farve til punktet
            g.FillEllipse(startBrush, scaledStartPoint.X - 5, scaledStartPoint.Y - 5, 10, 10); // Tegn punktet som en lille cirkel

            // Tegn de reflekterede laserbaner (grøn) i skalerede koordinater
            Pen reflectedLaserPen = new Pen(Color.Green, 2);  // Grøn pen til reflekteret laser
            for (int i = 0; i < laserPath.Count - 1; i++)
            {
                PointF scaledReflectedStart = ScalePoint(laserPath[i], scaleX, scaleY, xMin, yMin);
                PointF scaledReflectedEnd = ScalePoint(laserPath[i + 1], scaleX, scaleY, xMin, yMin);
                g.DrawLine(reflectedLaserPen, scaledReflectedStart, scaledReflectedEnd);
            }
        }

        private PointF ScalePoint(PointF point, double scaleX, double scaleY, double xMin, double yMin)
        {
            float scaledX = (float)((point.X - xMin) * scaleX);  // Skaler x-værdien
            float scaledY = (float)(-((point.Y - yMin) * scaleY) + this.ClientSize.Height);  // Skaler y-værdien og vend den (for korrekt koordinatsystem)
            return new PointF(scaledX, scaledY);
        }



        // Hjælpe-metode til at tegne funktioner
        /*private void DrawFunction(Graphics g, Func<double, double> funktion, double start, double end, Pen pen,
                                  double scaleX, double scaleY, double xMin, double yMin)
        {
            // Vi antager, at vi arbejder med et 2D-koordinatsystem, og vi skal transformere vores data til Formens pixel-koordinater.
            List<PointF> points = new List<PointF>();

            // For at tegne funktionen, beregner vi værdier fra start til slut (med en lille trin-størrelse)
            for (double x = start; x <= end; x += 0.01)
            {
                double y = funktion(x);
                if (!double.IsNaN(y))
                {
                    // Konverter fra funktionens koordinater til formens koordinater (pixel-koordinater)
                    float formX = (float)((x - xMin) * scaleX);  // Skaler x-værdien og juster for min-værdi
                    float formY = (float)(-((y - yMin) * scaleY) + this.ClientSize.Height);  // Omvendt y-akse og centrer på Form'en

                    points.Add(new PointF(formX, formY));
                }
            }

            // Tegn linjer mellem de beregnede punkter
            if (points.Count > 1)
            {
                g.DrawLines(pen, points.ToArray());
            }
        }*/
        private void DrawFunction(Graphics g, Func<double, double> funktion, double start, double end, Pen pen,
                          double scaleX, double scaleY, double xMin, double yMin)
        {
            List<PointF> points = new List<PointF>();

            // For at tegne funktionen, beregner vi værdier fra start til slut (med en lille trin-størrelse)
            for (double x = start; x <= end; x += 0.01)
            {
                double y = funktion(x);
                if (!double.IsNaN(y))
                {
                    // Skaler x-værdien og juster for min-værdi
                    float formX = (float)((x - xMin) * scaleX);

                    // Juster for den inverterede y-akse: jo højere y er, jo længere ned på skærmen bliver punktet
                    // Det betyder, at vi trækker y-værdien fra højden af formens klientområde
                    float formY = (float)((y - yMin) * scaleY);  // Skalere y-værdien
                    formY = this.ClientSize.Height - formY; // Inverter y-aksen, da Windows Forms går nedad

                    points.Add(new PointF(formX, formY));
                }
            }

            // Tegn linjer mellem de beregnede punkter
            if (points.Count > 1)
            {
                g.DrawLines(pen, points.ToArray());
            }
        }


        private void StartLaserReflections(Func<double, double> startFunction, double xStart, double yStart)
        {
            //Den nuværende funktion samt x- og y-værdi, sættes til at være startpunktet og startfunktionen for laseren. 
            Func<double, double> currentFunction = startFunction;
            double currentX = xStart;
            double currentY = yStart;

            int refleksionNr = 1;
            //Finder første retningsvektor for laseren. 
            (double dx, double dy) = BeregnRetningsvektor(startFunction, xStart);


            // Startpunkter
            laserPath.Add(new PointF((float)currentX, (float)currentY));


            //Hovedløkken, finder alle skæringspunkter og laserens reflektion ud fra det nærmeste skæringspunkt i vektorens retning. 
            while (true)
            {
                var (closestFunction, x, y) = FindClosestIntersection(currentFunction, currentX, currentY);
                //Hvis hverken x eller y har en værdi, er der ikke flere skæringer. 
                if (!x.HasValue || !y.HasValue)
                {
                    Console.WriteLine($"Refleksion #{refleksionNr}: Ingen flere skæringer – stop.");



                    Console.WriteLine($"Refleksion #{refleksionNr}: dx = {dx}, dy = {dy}");
                    // Beregn et punkt langt væk i den retning, laseren fortsætter
                    float extensionDistance = 2;  // Et punkt langt væk, f.eks. 100 enheder
                    double endX = currentX + dx * extensionDistance;
                    double endY = currentY + dy * extensionDistance;

                    laserPath.Add(new PointF((float)endX, (float)endY));  // Tilføj det forlængede punkt til laserens bane




                    //Der er ikke flere skæringer. While-løkken stoppes.
                    break;
                }
                //Printer det fundne skæringspunkt til konsollen. 
                Console.WriteLine($"Refleksion #{refleksionNr}: Skæringspunkt ({x.Value}, {y.Value})");
                //Der laves et objekt kaldet "reflektion" af klassen reflektionsberegner. 
                var refleksion = new Reflektionsberegner(currentX, currentY, currentFunction, closestFunction, x.Value, y.Value);
                //Reflektionen af laseren, ud fra det nærmeste skæringspunkt, beregnes af metoden CalculateReflection, fra objektet kaldet "refleksion".
                refleksion.CalculateReflection();
                //Laserens funktion og nuværende koordinater opdateres. 
                currentFunction = refleksion.GetReflectedFunction();
                currentX = x.Value;
                currentY = y.Value;



                // Tilføj reflekteret punkt til laserPath
                laserPath.Add(new PointF((float)currentX, (float)currentY));




                //Beregn ny retningsvektor efter refleksion.
                //refleksion.GetReflectedAngle() returnerer den udgående vinkel vOut (i radianer, da man ganger med Math.PI / 180).
                //Math.Cos giver x-komponenten (hvor meget laseren bevæger sig vandret).
                //Math.Sin giver y-komponenten (hvor meget den bevæger sig lodret).
                //(dx, dy) = (Math.Cos(refleksion.GetReflectedAngle() * Math.PI / 180), Math.Sin(refleksion.GetReflectedAngle() * Math.PI / 180));



                // Hent den nyeste refleksionsvektor fra refleksionsberegneren
                double reflectedDx = refleksion.GetReflectedDx();  // Brug den reflekterede dx
                double reflectedDy = refleksion.GetReflectedDy();  // Brug den reflekterede dy

                // Opdater dx og dy til de korrekte reflekterede værdier
                dx = reflectedDx;
                dy = reflectedDy;






                //Klar til næste reflektion.
                refleksionNr++;
            }
        }
        //Metoden finder ud fra de fundne skæringspunkter, den funktion der ligger tættest på forrige skæringspunkt. 

        private (Func<double, double>, double?, double?) FindClosestIntersection(Func<double, double> laserFunc, double xFrom, double yFrom)
        {
            double minDistance = double.MaxValue;
            Func<double, double> closestFunc = null;
            double? closestX = null;
            double? closestY = null;
            //Løkke der tjekker om laseren skærer med nogen objekter / andre funktioner.  
            foreach (var (funktion, start, end, navn) in funktioner)
            {
                //Metode der finder alle de mulige skæringer. 
                var skæring = Skæringsberegner.FindIntersection(laserFunc, funktion, start, end);
                if (skæring.x.HasValue && skæring.y.HasValue)
                {
                    double x = skæring.x.Value;
                    double y = skæring.y.Value;

                    //Debugging: Et tjek der specifikt tjekker om der er skæring med funktionen "l" samt beregner afstand og dotprodukt mellem de to vektorer (hvor meget de peger i samme retning). 
                    /*if (navn == "l")
                    {
                        Console.WriteLine($"POTENTIEL SKÆRING MED 'l' FUNDET VED (x: {x}, y: {y})");
                        Console.WriteLine($"  Afstand fra nuværende position: {Math.Sqrt(Math.Pow(x - xFrom, 2) + Math.Pow(y - yFrom, 2))}");
                        Console.WriteLine($"  Dotprodukt med retningsvektor: {(x - xFrom) * dx + (y - yFrom) * dy}");
                    }
                    */

                    //Finder det nærmeste skæringspunkt, hvor afstanden skal være positiv. 
                    //Definerer variabler, differencen mellem fundet skæringspunkt og skæringspunktet laseren kommer fra.. 
                    double diffX = x - xFrom;
                    double diffY = y - yFrom;
                   //Beregner tættest skæringspunkt. 
                    double distance = Math.Sqrt(diffX * diffX + diffY * diffY);
                    if (distance > 0.0001 && distance < minDistance)
                    {
                        minDistance = distance;
                        closestFunc = funktion;
                        closestX = x;
                        closestY = y;
                    }
                }
            }

            return (closestFunc, closestX, closestY);
        }
        //Metoden beregner retningsvektoren, hvor der vælges en lille forskydning i x-retningen, som bruges til at finde et punkt lidt fremme i funktionen. 
        //Retningen afhænger af fortegnet på deltaX, hvor hvis den er positiv vil den bevæge sig fremad i x-retningen, og modsat hvis den er negativ. Ex -0.01 eller 0.01. 
        private (double dx, double dy) BeregnRetningsvektor(Func<double, double> funktion, double xStart, double deltaX = -0.01)
        {
            //Vektor ud fra to punkter. 
            double x2 = xStart + deltaX;
            double y1 = funktion(xStart);
            double y2 = funktion(x2);

            double dx = x2 - xStart;
            double dy = y2 - y1;
            
            return (dx, dy);
        }

        
    }
}
