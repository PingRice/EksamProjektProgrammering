﻿    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using MathNet.Numerics;
    using MathNet.Numerics.Distributions;
    using MathNet.Numerics.RootFinding;

    namespace ProgEksamImplemenAfFunktioner
    {
        public class Reflektionsberegner
        {
             // Det beregnede reflectedDx og reflectedDy
            double reflectedDx;
            double reflectedDy;




        
        
            //Det punkt laserstrålen kommer fra.  
            double XStart;
            double YStart;

            //Definerer funktionen for laseren. 
            Func<double, double> LaserFunction;

            //Definerer funktion der beskriver det objekt / den funktion laseren rammer. 
            Func<double, double> SurfaceFunction;
            
            //x-værdien og y-værdien for skæringspunktet mellem laseren og objektet der skæres. 
            double XIntersection;
            double YIntersection;

            //Den udgående vinkel efter laserstrålen er reflekteret. 
            double vOut;
            //Hældningen af den reflekterede laserstråle. 
            double aOut;
            //Den reflekterede laserstråles skæringspunktet med y-aksen. 
            double bOut;
            
            public Reflektionsberegner(double xStart, double yStart, Func<double, double> laserFunction, Func<double, double> surfaceFunction, double xIntersection, double yIntersection)
            {
                //De interne variabler defineres. 
                XStart = xStart;
                YStart = yStart;
                LaserFunction = laserFunction;
                SurfaceFunction = surfaceFunction;
                XIntersection = xIntersection;
                YIntersection = yIntersection;
            }
        //Metoden der beregner reflektionen af laseren. 
        /*public void CalculateReflection()
        {
            //Beregn vektor for laser.
            double vx = XIntersection - XStart;
            double vy = YIntersection - YStart;

            //Beregn laserens vinkel i forhold til x-aksen. Kort sagt bruges Atan2 da den løser visse begrænsninger for den normale invers tangens.
            //Tager både y og x som input og bruger information om deres fortegn til at bestemme kvadranten.
            //Ud fra kvadranten x og y befinder sig i, beregnes vinklen forskelligt.
            double vLaser = Math.Atan2(vy, vx);

            //Beregn hældningen af objektets overflade, som hældning af lineær funktion ud fra to punkter på funktionen. 
            //Her bruges en lav skridtlængde på 0.001, for at finde hældningen så tæt på skæringspunktet som muligt.  
            double slopeFunction = (SurfaceFunction(XIntersection + 0.001) - SurfaceFunction(XIntersection)) / 0.001;
            //Vinklen mellem tangenten for et objekt (funktion) x-aksen findes ved at tage den inverse tangens til funktionen.
            double vFunction = Math.Atan(slopeFunction);

            //Beregn normalvektorens vinkel med x-aksen. (Tangentvinklen roteres 90 grader mod uret, og vi finder dermed normalen til funktionen)
            double vNormal = vFunction + Math.PI / 2;

            double normalDx = Math.Cos(vNormal);
            double normalDy = Math.Sin(vNormal);

            // Beregn dot-produktet mellem den indkommende vektor og normalvektoren
            double dotProduct = vx * normalDx + vy * normalDy;

            // Beregn spejling af vektoren omkring normalvektoren
            reflectedDx = vx - 2 * dotProduct * normalDx; // Spejl vektoren omkring normalvektoren (fx ved at fjerne projektionen)
            reflectedDy = vy - 2 * dotProduct * normalDy;

            // Hvis dot-produktet er negativt, betyder det, at refleksionen peger i den modsatte retning
            if (dotProduct < 0)
            {
                reflectedDx = -reflectedDx;
                reflectedDy = -reflectedDy;
                // Debugging
                Console.WriteLine("RETNINGEN ER BLEVET VENDT!!!!!!!");
            }

            // Beregn den reflekterede vinkel
            vOut = Math.Atan2(reflectedDy, reflectedDx); // Vinkel af den reflekterede vektor

            // Normaliser vinkel til at være mellem -pi og pi
            vOut = NormalizeAngle(vOut);


            //Beregn ny hældning og skæringspunkt med y-aksen.
            aOut = Math.Tan(vOut);
            bOut = YIntersection - aOut * XIntersection;

            //Debugging
            Console.WriteLine($"Spejlet funktion: y = {aOut}x + {bOut}");
            Console.WriteLine($"Laserens vektor: ({vx}, {vy}), vinkel: {vLaser}");
            Console.WriteLine($"Funktionens hældning: {slopeFunction}, vinkel: {vFunction}");
            Console.WriteLine($"Normalens vinkel: {vNormal}");
            Console.WriteLine($"Reflekteret vektor: [{reflectedDx}, {reflectedDy}]");
            Console.WriteLine($"Reflekteret vinkel: {vOut}");
            Console.WriteLine($"normalDx : {normalDx}");
            Console.WriteLine($"normalDy: {normalDy}");
        }*/
        public void CalculateReflection()
        {
            // Beregn vektor for laser.
            double vx = XIntersection - XStart;
            double vy = YIntersection - YStart;

            // Beregn laserens vinkel i forhold til x-aksen.
            double vLaser = Math.Atan2(vy, vx);

            // Beregn hældningen af objektets overflade
            double slopeFunction = (SurfaceFunction(XIntersection + 0.001) - SurfaceFunction(XIntersection)) / 0.001;
            double vFunction = Math.Atan(slopeFunction);

            // Beregn normalvektorens vinkel med x-aksen.
            double vNormal = vFunction + Math.PI / 2;

            // Beregn dot-produktet mellem den indkommende vektor og normalvektoren
            double dotProduct = vx * Math.Cos(vNormal) + vy * Math.Sin(vNormal);

            // Beregn spejlingen af vektoren omkring normalvektoren (spejling i forhold til normalvektoren)
            reflectedDx = vx - 2 * dotProduct * Math.Cos(vNormal);
            reflectedDy = vy - 2 * dotProduct * Math.Sin(vNormal);

            // Beregn den reflekterede vinkel
            vOut = Math.Atan2(reflectedDy, reflectedDx);

            // Normaliser vinklen til at være mellem -pi og pi.
            vOut = NormalizeAngle(vOut);

            // Beregn ny hældning og skæringspunkt med y-aksen.
            aOut = Math.Tan(vOut);
            bOut = YIntersection - aOut * XIntersection;

            // Debugging
            Console.WriteLine($"Spejlet funktion: y = {aOut}x + {bOut}");
            Console.WriteLine($"Laserens vektor: ({vx}, {vy}), vinkel: {vLaser}");
            Console.WriteLine($"Funktionens hældning: {slopeFunction}, vinkel: {vFunction}");
            Console.WriteLine($"Normalens vinkel: {vNormal}");
            Console.WriteLine($"Reflekteret vektor: [{reflectedDx}, {reflectedDy}]");
            Console.WriteLine($"Reflekteret vinkel: {vOut}");
        }


        private double NormalizeAngle(double angle)
            {
                //Normaliser vinkel til at være mellem -pi og pi.
                while (angle > Math.PI) angle -= 2 * Math.PI;
                while (angle < -Math.PI) angle += 2 * Math.PI;
                return angle;
            }

            //Metoden gør det nemt at få fat i den reflekterede vinkel. 
            public double GetReflectedAngle()
            {
                return vOut;
            }
            //Metoden gør det nemt at få fat i funktionen for laseren, efter den er blevet reflekteret. 
            public Func<double, double> GetReflectedFunction()
            {
                return x => aOut * x + bOut;
            }

            // Metoder til at få de reflekterede vektorer
            public double GetReflectedDx() => reflectedDx;
            public double GetReflectedDy() => reflectedDy;


    }
    }
