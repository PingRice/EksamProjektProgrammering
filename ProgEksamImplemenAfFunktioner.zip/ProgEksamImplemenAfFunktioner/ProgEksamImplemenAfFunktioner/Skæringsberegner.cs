﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathNet.Numerics.RootFinding;

namespace ProgEksamImplemenAfFunktioner
{
    internal class Skæringsberegner
    {
        public static (double? x, double? y) FindIntersection(Func<double, double> f1, Func<double, double> f2, double start, double end)
        {
            // Definerer en ny funktion, der repræsenterer forskellen mellem de to funktioner. Skæringspunkt mellem to funktioner findes ved at sætte dem lig hinanden.
            //Dette kan omskrives til: f_1(x)-f_2(x)=0, hvor vi efter ved at definere en funktion h som dette, kan finde dens nulpunkter, der hvor den er lig 0.
            //Hvilket også er der hvor funktionerne er lig hinanden.
            Func<double, double> h = x =>
            {
                //Hvis x er uden for intervallet [start,end], returneres double.NaN, hvilket betyder at h(x) ikke er defineret der. 
                //Der er dermed ikke noget skæringspunkt. Ellers defineres funktionen h som den ene funktion minus den anden. 
                if (x >= start && x <= end)
                {
                    return f1(x) - f2(x);
                }
                else
                {
                    return double.NaN;
                }
            };
            //Hvis der ikke kan findes et nulpunkt for funktionen, kastes en undtagelse, hvorefter try-blokken stopper og springer over til catch-blokken. 
            try
            {
                //Finder skæringspunktet ved hjælp af MathNet. Dette gøres ved at finde nulpunker for funktionen h i det givne interval.
                double x_skæring = Bisection.FindRoot(h, start, end);

                if (double.IsNaN(x_skæring))
                {
                    //Der blev ikke fundet et gyldigt skæringspunkt i intervallet... 
                    return (null, null);
                }
                else
                {
                    //Da der er fundet en x-værdi for skæringspunktet, kan y-værdien for dette punkt beregnes. 
                    double y_skæring = f1(x_skæring);
                    return (x_skæring, y_skæring);
                }
            }

            catch (MathNet.Numerics.NonConvergenceException)
            {
                //Hvis Bisection.FindRoot ikke kan finde et skæringspunkt (x_skæring), og kaster undtagelsen NonConvergenceException, returneres også null. 
                return (null, null);
            }
        }
    }
}
